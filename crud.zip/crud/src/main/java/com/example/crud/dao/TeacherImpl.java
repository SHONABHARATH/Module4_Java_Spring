package com.example.crud.dao;

import com.example.crud.entity.Teacher;
import jakarta.persistence.EntityManager;
import jakarta.persistence.TypedQuery;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
@Repository
public class TeacherImpl implements TeacherDAO {
    public EntityManager entityManager;

    public TeacherImpl(EntityManager entityManager) {
        this.entityManager = entityManager;
    }

    @Transactional
    @Override
    public void save(Teacher theteacher) {
        entityManager.persist(theteacher);
    }

    @Override
    public Teacher findbyID(int id) {
        return entityManager.find(Teacher.class,id);
    }

    @Override
    public List<Teacher> findAll() {
        TypedQuery<Teacher> query = entityManager.createQuery("from Teacher order by name",Teacher.class);
        return query.getResultList();
    }

    @Override
    public List<Teacher> findbyname(String name) {
        TypedQuery<Teacher> query = entityManager.createQuery("from Teacher where name=:data",Teacher.class);
        query.setParameter("data",name);
        return query.getResultList();
    }
    @Transactional
    @Override
    public void update(Teacher theteacher) {
        entityManager.merge(theteacher);

    }

    @Transactional
    @Override
    public int deletebyID(int id) {

        Teacher temp = entityManager.find(Teacher.class,id);
        entityManager.remove(temp);
        return 0;
    }
    @Transactional
    @Override
    public int deleteAll() {
        int num = entityManager.createQuery("delete from Teacher").executeUpdate();
        return num;
    }
}
