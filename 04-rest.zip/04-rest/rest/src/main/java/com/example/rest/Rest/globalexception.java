package com.example.rest.Rest;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

@ControllerAdvice
public class globalexception {


    @ExceptionHandler
    public ResponseEntity<StudentErrorResponse> handleException (StudentException e)
    {
        StudentErrorResponse error = new StudentErrorResponse();
        error.setStatusCode(HttpStatus.NOT_FOUND.value());
        error.setMessage(e.getMessage());
        error.setTimestamp(String.valueOf(System.currentTimeMillis()));
        return new ResponseEntity<>(error,HttpStatus.NOT_FOUND);
    }

    @ExceptionHandler
    public ResponseEntity<StudentErrorResponse> handleException(Exception exe)
    {
        StudentErrorResponse error = new StudentErrorResponse();
        error.setStatusCode(HttpStatus.BAD_REQUEST.value());
        error.setMessage(exe.getMessage());
        error.setTimestamp(String.valueOf(System.currentTimeMillis()));

        return new ResponseEntity<>(error,HttpStatus.NOT_FOUND);
    }

}
