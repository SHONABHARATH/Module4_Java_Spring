package com.example.crud.dao;

import com.example.crud.entity.Flower;

import java.util.List;

public interface FlowerDAO {

    void create(Flower theflower);
    List<Flower> findAll();
    Flower findbyId(int id);
    List<Flower> findbyName(String name);
    void update(Flower theflower);
    void deletebyId(int id);
    int deleteall();




}
