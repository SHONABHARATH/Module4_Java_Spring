package com.example.crud.dao;

import com.example.crud.entity.Flower;
import jakarta.persistence.EntityManager;
import jakarta.persistence.TypedQuery;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Repository
public class FlowerDAOImpl implements FlowerDAO{

    public EntityManager entityManager;

    public FlowerDAOImpl(EntityManager entityManager) {
        this.entityManager = entityManager;
    }
    @Transactional
    @Override
    public void create(Flower theflower) {
         entityManager.persist(theflower);
    }

    @Override
    public List<Flower> findAll() {
        TypedQuery<Flower> query = entityManager.createQuery("from Flower",Flower.class);
        return query.getResultList();
    }

    @Override
    public Flower findbyId(int id) {

        return entityManager.find(Flower.class,id);
    }

    @Override
    public List<Flower> findbyName(String name) {
        TypedQuery<Flower> query = entityManager.createQuery("from Flower where name=:data",Flower.class);
        query.setParameter("data",name);
        return query.getResultList();
    }

    @Transactional
    @Override
    public void update(Flower theflower) {
        entityManager.merge(theflower);

    }
    @Transactional
    @Override
    public void deletebyId(int id) {
        Flower theflower = entityManager.find(Flower.class,id);
        entityManager.remove(theflower);
    }
    @Transactional
    @Override
    public int deleteall() {
        int num = entityManager.createQuery("delete from Flower").executeUpdate();
        return num;
    }
}
