package com.example.crud.dao;

import com.example.crud.entity.Police;

import java.util.List;

public interface PoliceDAO {



    void save(Police thePolice);

    Police findbyID(int id);

    List<Police> findAll();

    List<Police> findbyname(String name);

    void update(Police thePolice);

    int deletebyid(int id);

    int deleteall();
}
