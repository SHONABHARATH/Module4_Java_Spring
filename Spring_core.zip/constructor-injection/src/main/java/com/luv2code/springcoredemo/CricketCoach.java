package com.luv2code.springcoredemo;


import org.springframework.stereotype.Component;

@Component

public class CricketCoach implements Coach{

    public CricketCoach()
    {
        System.out.println("constructor "+getClass().getName() );
    }

    @Override
    public String getDailyWorkout() {

        return "practice";
    }
}
