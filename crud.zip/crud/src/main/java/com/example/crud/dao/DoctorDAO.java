package com.example.crud.dao;

import com.example.crud.entity.Doctor;

import java.util.List;

public interface DoctorDAO {
    void save(Doctor theDoctor);

    Doctor findbyID(int id);

    List<Doctor> findAll();

    void update(Doctor theDoctor);

    void delete(int id);
}
