package com.luv2code.springcoredemo;

import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

@Component

public class BacketballCoach implements Coach{
    @Override
    public String getDailyWorkout() {
        return "DAILY PRACTISE";
    }
}
