package com.luv2code.springcoredemo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class Controller {


    private ball myball;

    @Autowired
    public void setball(ball theball)
    {
        myball = theball;
    }

    @GetMapping("/getBalls")
        private String getBalls() {
        return myball.getBalls();
        }

}
