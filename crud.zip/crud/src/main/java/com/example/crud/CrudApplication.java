package com.example.crud;

import com.example.crud.dao.*;
import com.example.crud.entity.*;
import org.hibernate.boot.model.source.internal.hbm.AttributesHelper;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import javax.print.Doc;
import java.util.List;

import static org.springframework.data.jpa.domain.AbstractPersistable_.id;

@SpringBootApplication
public class CrudApplication {

	public static void main(String[] args) {
		SpringApplication.run(CrudApplication.class, args);
	}



	@Bean
//	public CommandLineRunner commandLineRunner(StudentDAO studentDAO)
//	public CommandLineRunner commandLineRunner(EmployeeDAO employeeDAO)
//	public CommandLineRunner commandLineRunner(DoctorDAO doctorDAO)
//	public CommandLineRunner commandLineRunner(PoliceDAO policeDAO)
//	public CommandLineRunner commandLineRunner(TeacherDAO teacherDAO)
	public CommandLineRunner commandLineRunner(FlowerDAO flowerDAO)

	{
		return runner -> deletealLLLl1(flowerDAO);
		//updateflower(flowerDAO);
		//finall(flowerDAO);
				//findbyIddd(flowerDAO);

		//createFlower(flowerDAO);



		//deletealLLLl(teacherDAO);
		//deletebyiddd(teacherDAO);
		//updateteacher(teacherDAO);
		//findbyname(teacherDAO);
		//findAl(teacherDAO);
		//findbyidd(teacherDAO);
		//createTeacher(teacherDAO);










		//deletealll(policeDAO);
				//deletebyidd(policeDAO);
		//updatename(policeDAO);
		//findname(policeDAO);
		//findalll(policeDAO);
				//findbyID(policeDAO);
				//createPolice(policeDAO);








				//deletebyid(doctorDAO);
				//updatedoctor(doctorDAO);
				//findall(doctorDAO);
				//findbyid(doctorDAO);
				//createDoctor(doctorDAO);

				// deleteeverything(employeeDAO);
				// deleteemployee(employeeDAO);
				// updateemployee(employeeDAO);
				// readall(employeeDAO);
				// reademployee(employeeDAO);
				// createemployee(employeeDAO);


		//		deleteall(studentDAO);
		// deletestudent(studentDAO);
			//	updateStudent(studentDAO);
			//	queryforStudentbyFirstName(studentDAO);
			//	queryforStudent(studentDAO);
			//	readStudent(studentDAO);
			//	createStudent(studentDAO);
	}

	private void deletealLLLl1(FlowerDAO flowerDAO) {
		int num = flowerDAO.deleteall();
		System.out.println("Update details: "+num);
	}

	private void updateflower(FlowerDAO flowerDAO) {
		int id = 5;
		Flower obj = flowerDAO.findbyId(id);
		obj.setName("sunflower");
		flowerDAO.update(obj);
		System.out.println("Update info: "+obj);

	}

	private void finall(FlowerDAO flowerDAO) {
		List<Flower> flower = flowerDAO.findAll();
		for(Flower flo : flower)
		{
			System.out.println("All details: "+flo);
		}
	}

	private void findbyIddd(FlowerDAO flowerDAO) {
		int id=2;
		Flower theflower = flowerDAO.findbyId(id);
		System.out.println("Flower is : "+theflower);
	}

	private void createFlower(FlowerDAO flowerDAO) {
		Flower theflower = new Flower("rose","purple");
		flowerDAO.create(theflower);
		System.out.println("Flower db : "+theflower.getId());
	}

	private void deletealLLLl(TeacherDAO teacherDAO) {
		teacherDAO.deleteAll();
	}

	private void deletebyiddd(TeacherDAO teacherDAO) {
		int id=1;
		int num = teacherDAO.deletebyID(id);
		System.out.println("Remaining details: "+num);


	}

	private void updateteacher(TeacherDAO teacherDAO) {
		int id =1;
		Teacher temp = teacherDAO.findbyID(id);
		temp.setSection(1);
		teacherDAO.update(temp);
		System.out.println("Updated details: "+temp);
	}

	private void findbyname(TeacherDAO teacherDAO) {
		List<Teacher> temp = teacherDAO.findbyname("Shona");
		for(Teacher temp1 : temp)
		{
			System.out.println("Details are: "+temp1);
		}
	}

	private void findAl(TeacherDAO teacherDAO) {
		List<Teacher> temp = teacherDAO.findAll();
		System.out.println("All Details: "+temp);
	}

	private void findbyidd(TeacherDAO teacherDAO) {
		Teacher temp = new Teacher("Shona",10);
		teacherDAO.save(temp);
		System.out.println(temp);
		int id=1;
		Teacher myteacher = teacherDAO.findbyID(id);
		System.out.println("Details: "+myteacher);


	}

	private void createTeacher(TeacherDAO teacherDAO) {
		Teacher temp = new Teacher("Sangeetha",7);
		teacherDAO.save(temp);
		System.out.println(temp);
	}

	private void deletealll(PoliceDAO policeDAO) {
		int num = policeDAO.deleteall();
		System.out.println("Update details: "+num);
	}

	private void deletebyidd(PoliceDAO policeDAO) {
		int id = 1;
		int num = policeDAO.deletebyid(id);
		System.out.println("Update details: "+num);
	}

	private void updatename(PoliceDAO policeDAO) {
		int id = 3;
		Police mypolice = policeDAO.findbyID(id);
		mypolice.setName("AAA");
		policeDAO.update(mypolice);
		System.out.println("Update details: "+mypolice);

	}

	private void findname(PoliceDAO policeDAO) {
		List<Police> temp = policeDAO.findbyname("YYY");
		for(Police temp1 : temp)
		{
			System.out.println(temp1);
		}
	}

	private void findalll(PoliceDAO policeDAO) {
		List<Police> temp = policeDAO.findAll();
		for(Police temp1 : temp)
		{
			System.out.println("All details: "+temp1);
		}
	}

	private void findbyID(PoliceDAO policeDAO) {
		Police temp = new Police("ZZZ","IPS");
		policeDAO.save(temp);
		int id = temp.getId();
		Police policeDAO1 = policeDAO.findbyID(id);
		System.out.println("Details: "+id);
	}

	private void createPolice(PoliceDAO policeDAO) {
		Police temp = new Police("YYY","DCP");
		policeDAO.save(temp);
		System.out.println("Details: "+temp);
	}


	private void deletebyid(DoctorDAO doctorDAO) {
		int id = 1;
		doctorDAO.delete(id);
	}

	private void updatedoctor(DoctorDAO doctorDAO) {
		int id=1;
		Doctor myDoctor = doctorDAO.findbyID(id);

		// change name

		myDoctor.setName("sange");
		// update the name

		doctorDAO.update(myDoctor);

	}

	private void findall(DoctorDAO doctorDAO) {

		List<Doctor> thedoctor = doctorDAO.findAll();
		for (Doctor temp : thedoctor) {
			System.out.println(temp);
		}
	}

	private void findbyid(DoctorDAO doctorDAO) {
		Doctor temp = new Doctor("CCC","Gyno");
		doctorDAO.save(temp);
		int theID = temp.getId();
		Doctor mydoctor = doctorDAO.findbyID(theID);
		System.out.println("Doctor: "+mydoctor);
	}

	public void createDoctor(DoctorDAO doctorDAO)
	{
		Doctor temp = new Doctor("BBB","Ortho");
		doctorDAO.save(temp);
		System.out.println("details: "+temp.getId());

	}




























	private void deleteeverything(EmployeeDAO employeeDAO) {
		int num = employeeDAO.deleteall();
	}

	private void deleteemployee(EmployeeDAO employeeDAO) {
		int employeeid = 2;
		employeeDAO.delete(employeeid);
	}

	private void updateemployee(EmployeeDAO employeeDAO) {
		int employeeid = 2;
		Employee myEmployee = employeeDAO.findbyID(employeeid);

		myEmployee.setName("sange");

		employeeDAO.update(myEmployee);

		System.out.println("Update student "+myEmployee);
	}

	private void readall(EmployeeDAO employeeDAO) {
		List<Employee> theEmployee = employeeDAO.findAll();
		for (Employee temp : theEmployee)
		{
			System.out.println(temp);
		}
	}

	private void reademployee(EmployeeDAO employeeDAO) {
		Employee temp = new Employee("sachin","sachin@mail.com");
		employeeDAO.save(temp);
		System.out.println("Display Employee id...."+temp.getEid());
		int theid = temp.getEid();
		System.out.println("Display Employee id...."+theid);
		System.out.println("Retrieve Employee id...."+theid);
		Employee myEmployee = employeeDAO.findbyID(theid);
		System.out.println("student id...."+myEmployee);

	}

	private void createemployee(EmployeeDAO employeeDAO) {
		Employee temp = new Employee("shona","shona@mail.com");
		employeeDAO.save(temp);
		System.out.println("Display Student id...."+temp.getEid());
	}


















	private void deleteall(StudentDAO studentDAO) {
		System.out.println("Delete all students");
		int num = studentDAO.deleteAll();
		System.out.println("Count "+num);
	}

	private void deletestudent(StudentDAO studentDAO) {
		int studentId = 3;
		System.out.println("Retrieve student with id "+ studentId);
		studentDAO.delete(studentId);

	}

	private void updateStudent(StudentDAO studentDAO) {

		// retrieve data by id
		int studentId = 3;
		System.out.println("Retrieve student with id "+ studentId);
		Student myStudent = studentDAO.findbyID(studentId);

		// change name
		System.out.println("Updating student ");
		myStudent.setFirstName("sange");
		// update the name

		studentDAO.update(myStudent);

		// display
		System.out.println("Update student "+myStudent);
	}

	private void queryforStudentbyFirstName(StudentDAO studentDAO) {
		// get list of students
		List<Student> theStudents = studentDAO.findbyfirstname("shona");

		// display list of student
		for (Student tempstudents : theStudents)
		{
			System.out.println(tempstudents);
		}
	}

	private void queryforStudent(StudentDAO studentDAO) {

		// get list of students
		List<Student> theStudents = studentDAO.findAll();

		// display list of student
		for (Student tempstudents : theStudents)
		{
			System.out.println(tempstudents);
		}


	}



	private void readStudent(StudentDAO studentDAO) {

		System.out.println("Create Student details....");
		Student tempstudent = new Student("shachin","bharath","shachin@gmail.com");

		System.out.println("Save Student details....");
		studentDAO.save(tempstudent);

		int theid = tempstudent.getId();
		System.out.println("Display Student id...."+theid);

		System.out.println("Retrieve Student id...."+theid);
		Student myStudent = studentDAO.findbyID(theid);

		System.out.println("student id...."+myStudent);

	}

	private void createStudent(StudentDAO studentDAO) {

		System.out.println("Create Student details....");
		Student tempstudent = new Student("shona","bharth","shona@gmail.com");

		System.out.println("Save Student details....");
		studentDAO.save(tempstudent);

		System.out.println("Display Student id...."+tempstudent.getId());



	}

}
