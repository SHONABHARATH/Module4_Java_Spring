package com.luv2code.springcoredemo;

public class SwimCoach implements Coach{



    @Override
    public String getDailyWorkout() {
        return "1000 metres everyday";
    }
}
