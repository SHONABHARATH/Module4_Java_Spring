package com.example.crud;

import com.example.crud.dao.DoctorDAO;
import com.example.crud.dao.EmployeeDAO;
import com.example.crud.dao.StudentDAO;
import com.example.crud.entity.Doctor;
import com.example.crud.entity.Employee;
import com.example.crud.entity.Student;
import org.hibernate.boot.model.source.internal.hbm.AttributesHelper;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import javax.print.Doc;
import java.util.List;

@SpringBootApplication
public class CrudApplication {

	public static void main(String[] args) {
		SpringApplication.run(CrudApplication.class, args);
	}



	@Bean
//	public CommandLineRunner commandLineRunner(StudentDAO studentDAO)
//	public CommandLineRunner commandLineRunner(EmployeeDAO employeeDAO)
	public CommandLineRunner commandLineRunner(DoctorDAO doctorDAO)

	{
		return runner -> deletebyid(doctorDAO);
				//updatedoctor(doctorDAO);
				//findall(doctorDAO);
				//findbyid(doctorDAO);
				//createDoctor(doctorDAO);

				// deleteeverything(employeeDAO);
				// deleteemployee(employeeDAO);
				// updateemployee(employeeDAO);
				// readall(employeeDAO);
				// reademployee(employeeDAO);
				// createemployee(employeeDAO);


		//		deleteall(studentDAO);
		// deletestudent(studentDAO);
			//	updateStudent(studentDAO);
			//	queryforStudentbyFirstName(studentDAO);
			//	queryforStudent(studentDAO);
			//	readStudent(studentDAO);
			//	createStudent(studentDAO);
	}

	private void deletebyid(DoctorDAO doctorDAO) {
		int id = 1;
		doctorDAO.delete(id);
	}

	private void updatedoctor(DoctorDAO doctorDAO) {
		int id=1;
		Doctor myDoctor = doctorDAO.findbyID(id);

		// change name

		myDoctor.setName("sange");
		// update the name

		doctorDAO.update(myDoctor);

	}

	private void findall(DoctorDAO doctorDAO) {

		List<Doctor> thedoctor = doctorDAO.findAll();
		for (Doctor temp : thedoctor) {
			System.out.println(temp);
		}
	}

	private void findbyid(DoctorDAO doctorDAO) {
		Doctor temp = new Doctor("CCC","Gyno");
		doctorDAO.save(temp);
		int theID = temp.getId();
		Doctor mydoctor = doctorDAO.findbyID(theID);
		System.out.println("Doctor: "+mydoctor);
	}

	public void createDoctor(DoctorDAO doctorDAO)
	{
		Doctor temp = new Doctor("BBB","Ortho");
		doctorDAO.save(temp);
		System.out.println("details: "+temp.getId());

	}




























	private void deleteeverything(EmployeeDAO employeeDAO) {
		int num = employeeDAO.deleteall();
	}

	private void deleteemployee(EmployeeDAO employeeDAO) {
		int employeeid = 2;
		employeeDAO.delete(employeeid);
	}

	private void updateemployee(EmployeeDAO employeeDAO) {
		int employeeid = 2;
		Employee myEmployee = employeeDAO.findbyID(employeeid);

		myEmployee.setName("sange");

		employeeDAO.update(myEmployee);

		System.out.println("Update student "+myEmployee);
	}

	private void readall(EmployeeDAO employeeDAO) {
		List<Employee> theEmployee = employeeDAO.findAll();
		for (Employee temp : theEmployee)
		{
			System.out.println(temp);
		}
	}

	private void reademployee(EmployeeDAO employeeDAO) {
		Employee temp = new Employee("sachin","sachin@mail.com");
		employeeDAO.save(temp);
		System.out.println("Display Employee id...."+temp.getEid());
		int theid = temp.getEid();
		System.out.println("Display Employee id...."+theid);
		System.out.println("Retrieve Employee id...."+theid);
		Employee myEmployee = employeeDAO.findbyID(theid);
		System.out.println("student id...."+myEmployee);

	}

	private void createemployee(EmployeeDAO employeeDAO) {
		Employee temp = new Employee("shona","shona@mail.com");
		employeeDAO.save(temp);
		System.out.println("Display Student id...."+temp.getEid());
	}


















	private void deleteall(StudentDAO studentDAO) {
		System.out.println("Delete all students");
		int num = studentDAO.deleteAll();
		System.out.println("Count "+num);
	}

	private void deletestudent(StudentDAO studentDAO) {
		int studentId = 3;
		System.out.println("Retrieve student with id "+ studentId);
		studentDAO.delete(studentId);

	}

	private void updateStudent(StudentDAO studentDAO) {

		// retrieve data by id
		int studentId = 3;
		System.out.println("Retrieve student with id "+ studentId);
		Student myStudent = studentDAO.findbyID(studentId);

		// change name
		System.out.println("Updating student ");
		myStudent.setFirstName("sange");
		// update the name

		studentDAO.update(myStudent);

		// display
		System.out.println("Update student "+myStudent);
	}

	private void queryforStudentbyFirstName(StudentDAO studentDAO) {
		// get list of students
		List<Student> theStudents = studentDAO.findbyfirstname("shona");

		// display list of student
		for (Student tempstudents : theStudents)
		{
			System.out.println(tempstudents);
		}
	}

	private void queryforStudent(StudentDAO studentDAO) {

		// get list of students
		List<Student> theStudents = studentDAO.findAll();

		// display list of student
		for (Student tempstudents : theStudents)
		{
			System.out.println(tempstudents);
		}


	}



	private void readStudent(StudentDAO studentDAO) {

		System.out.println("Create Student details....");
		Student tempstudent = new Student("shachin","bharath","shachin@gmail.com");

		System.out.println("Save Student details....");
		studentDAO.save(tempstudent);

		int theid = tempstudent.getId();
		System.out.println("Display Student id...."+theid);

		System.out.println("Retrieve Student id...."+theid);
		Student myStudent = studentDAO.findbyID(theid);

		System.out.println("student id...."+myStudent);

	}

	private void createStudent(StudentDAO studentDAO) {

		System.out.println("Create Student details....");
		Student tempstudent = new Student("shona","bharth","shona@gmail.com");

		System.out.println("Save Student details....");
		studentDAO.save(tempstudent);

		System.out.println("Display Student id...."+tempstudent.getId());



	}

}
