package com.example.crud.dao;

import com.example.crud.entity.Employee;

import java.util.List;

public interface EmployeeDAO {

    List<Employee> findAll();

    Employee findbyID(int theID);

    Employee save(Employee theEmployee);

    void remove(int theID);
}
