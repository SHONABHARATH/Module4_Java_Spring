package com.example.crud.service;

import com.example.crud.entity.Employee;
import org.springframework.stereotype.Service;

import java.util.List;


public interface EmployeeService {
    List<Employee> findAll();
    Employee findbyID(int theID);

    Employee save(Employee theEmployee);

    void remove(int theID);
}
