package com.example.rest.Rest;


import com.example.rest.entity.Student;
import jakarta.annotation.PostConstruct;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/api")
public class StudentController {

    private List<Student> theStudents;

    @PostConstruct
            public void loadStudents() {
        theStudents = new ArrayList<>();
        theStudents.add(new Student("Shona", "Bharath"));
        theStudents.add(new Student("Shachin", "Bharath"));
        theStudents.add(new Student("Sangeetha", "Bharath"));
    //    return theStudents;

    }



    @GetMapping("/student")
            public List<Student> getStudents()

    {
 //       List<Student> theStudents = new ArrayList<>();
//
//        theStudents.add(new Student("Shona", "Bharath"));
//        theStudents.add(new Student("Shachin", "Bharath"));
//        theStudents.add(new Student("Sangeetha", "Bharath"));
//
      return theStudents;
    }

    @GetMapping("/student/{studentID}")
    public Student getStudent (@PathVariable int studentID)
    {
        if(studentID>= getStudents().size()||studentID<0)
            throw new StudentException("Student id not found "+studentID);


        return theStudents.get(studentID);
    }



































}
