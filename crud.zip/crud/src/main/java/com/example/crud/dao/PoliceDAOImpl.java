package com.example.crud.dao;

import com.example.crud.entity.Police;
import jakarta.persistence.EntityManager;
import jakarta.persistence.TypedQuery;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Repository
public class PoliceDAOImpl implements PoliceDAO {

    public EntityManager entityManager;

    public PoliceDAOImpl(EntityManager entityManager) {
        this.entityManager = entityManager;
    }

    @Transactional
    @Override
    public void save(Police thePolice) {
        entityManager.persist(thePolice);
    }

    @Override
    public Police findbyID(int id) {
        return entityManager.find(Police.class,id);
    }

    @Override
    public List<Police> findAll() {
        TypedQuery<Police> query = entityManager.createQuery("from Police order by name", Police.class);
        return query.getResultList();
    }

    @Override
    public List<Police> findbyname(String name) {
        TypedQuery<Police> query = entityManager.createQuery("from Police where name=:data", Police.class);
        query.setParameter("data",name);
        return query.getResultList();
    }

    @Transactional
    @Override
    public void update(Police thePolice) {
        entityManager.merge(thePolice);
    }
    @Transactional
    @Override
    public int deletebyid(int id) {
        Police mypolice = entityManager.find(Police.class,id);
            entityManager.remove(mypolice);
        return 0;
    }
@Transactional
    @Override
    public int deleteall() {
        int num = entityManager.createQuery("delete from Police").executeUpdate();
        return num;

    }
}


