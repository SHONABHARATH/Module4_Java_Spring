package com.example.crud.dao;

import com.example.crud.entity.Student;
import jakarta.persistence.EntityManager;
import jakarta.persistence.Table;
import jakarta.persistence.TypedQuery;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.lang.reflect.Type;
import java.util.List;

@Repository
public class StudentDAOImpl implements StudentDAO{

    private final EntityManager entityManager;

    @Autowired
    public StudentDAOImpl(EntityManager entityManager) {
        this.entityManager = entityManager;
    }

    @Override
    @Transactional
    public void save(Student theStudent) {
        entityManager.persist(theStudent);
    }

    @Override
    public Student findbyID(Integer id) {
        return entityManager.find(Student.class,id);
    }

    @Override
    public List<Student> findAll() {
        // create query
        TypedQuery<Student> theQuery = entityManager.createQuery("FROM Student order by lastName",Student.class);
        // return
        return theQuery.getResultList();
    }

    @Override
    public List<Student> findbyfirstname(String thefirstName) {
        TypedQuery<Student> theQuery = entityManager.createQuery("FROM Student where firstName=:theData",Student.class);

        //set parameter
        theQuery.setParameter("theData",thefirstName);

        return theQuery.getResultList();
    }

    @Override
    @Transactional
    public void update(Student theStudent) {
        entityManager.merge(theStudent);

    }

    @Override
    @Transactional
    public void delete(Integer id) {
        // RETRIEVE
       Student theStudent = entityManager.find(Student.class,id);

        //DELETE
        entityManager.remove(theStudent);

    }

    @Override
    @Transactional
    public int deleteAll() {

        int number = entityManager.createQuery("DELETE FROM Student").executeUpdate();

        return number;

    }
}
