package com.example.rest.Rest;

public class StudentErrorResponse {

    private int StatusCode;

    public int getStatusCode() {
        return StatusCode;
    }

    public void setStatusCode(int statusCode) {
        StatusCode = statusCode;
    }

    public String getMessage() {
        return Message;
    }

    public void setMessage(String message) {
        Message = message;
    }

    public String getTimestamp() {
        return Timestamp;
    }

    public void setTimestamp(String timestamp) {
        Timestamp = timestamp;
    }

    private String Message;

    private String Timestamp;

    public StudentErrorResponse(int statusCode, String message, String timestamp) {
        StatusCode = statusCode;
        Message = message;
        Timestamp = timestamp;
    }

    public StudentErrorResponse()
    {

    }
}
