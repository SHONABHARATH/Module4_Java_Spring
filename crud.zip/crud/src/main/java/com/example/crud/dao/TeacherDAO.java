package com.example.crud.dao;

import com.example.crud.entity.Teacher;

import java.util.List;

public interface TeacherDAO {

    void save(Teacher theteacher);
    Teacher findbyID(int id);
    List<Teacher> findAll();
    List<Teacher> findbyname(String name);
    void update(Teacher theteacher);
    int deletebyID(int id);
    int deleteAll();
}
