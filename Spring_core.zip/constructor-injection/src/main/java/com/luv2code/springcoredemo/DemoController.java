package com.luv2code.springcoredemo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;


@RestController
public class DemoController  {


    private Coach myCoach;
    private Coach anotherCoach;

    @Autowired
    public DemoController(@Qualifier("swimCoach") Coach theCoach)

    {
        System.out.println("Constructor: " + getClass().getSimpleName());
        myCoach = theCoach;


    }

    @GetMapping("/kk")
    private String getDailyWorkout()
    {
        return myCoach.getDailyWorkout();
    }


}
