package com.luv2code.springcoredemo;

import org.springframework.stereotype.Component;

@Component
public class football implements ball{

    @Override
    public String getBalls()
    {
        return "gtg";
    }

}
