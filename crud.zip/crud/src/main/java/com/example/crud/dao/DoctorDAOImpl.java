package com.example.crud.dao;

import com.example.crud.entity.Doctor;
import jakarta.persistence.EntityManager;
import jakarta.persistence.TypedQuery;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Repository
public class DoctorDAOImpl implements DoctorDAO{

    @Autowired
    public DoctorDAOImpl(EntityManager entityManager) {
        this.entityManager = entityManager;
    }

    public EntityManager entityManager;

    @Transactional
    @Override
    public void save(Doctor theDoctor) {
        entityManager.persist(theDoctor);
    }

    @Override
    public Doctor findbyID(int id) {
        return entityManager.find(Doctor.class,id);
    }

    @Override
    public List<Doctor> findAll() {
        TypedQuery<Doctor> theQuery = entityManager.createQuery("from Hospital order by designation",Doctor.class);
        return theQuery.getResultList();
    }

    @Override
    @Transactional
    public void update(Doctor theDoctor) {
        entityManager.merge(theDoctor);
    }

    @Transactional
    @Override
    public void delete(int id) {
        Doctor theDoctor = entityManager.find(Doctor.class,id);
        entityManager.remove(theDoctor);
    }


}
